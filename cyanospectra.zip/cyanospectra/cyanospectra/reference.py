"""Versioned reference spectral library (JSON / CSV), one record per spectrum with documented origin.

A record is either a tabulated spectrum ('wavelength' + 'absorbance') or a parametric one
('bands': [{centre, fwhm, height}]). Rendered spectra are normalised to unit area so that
an NNLS weight equals the integrated absorption (area) of that pigment.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from ._utils import fwhm_to_sigma, gaussian, trapz
from .pigments import PIGMENT_BANDS, PIGMENTS

DATA_DIR = Path(__file__).parent / "data"
BUILTIN_PATH = DATA_DIR / "reference_library.json"
_FINE = np.arange(300.0, 901.0)
REQUIRED = ("id", "pigment", "origin", "method", "source")


class ReferenceLibrary:
    def __init__(self, spectra=None, version="0.0.0", description=""):
        self.version, self.description = version, description
        self.spectra = []
        for s in spectra or []:
            self.add(s)

    # -- management
    def add(self, record: dict):
        missing = [k for k in REQUIRED if not record.get(k)]
        if missing:
            raise ValueError(f"reference record must document {missing}")
        if "bands" not in record and not ("wavelength" in record and "absorbance" in record):
            raise ValueError("record needs 'bands' or 'wavelength'+'absorbance'")
        if any(s["id"] == record["id"] for s in self.spectra):
            raise ValueError(f"duplicate id {record['id']}")
        self.spectra.append(dict(record))

    def pigments(self):
        return [p for p in PIGMENTS if any(s["pigment"] == p for s in self.spectra)]

    def select(self, pigment, spectrum_id=None):
        for s in self.spectra:
            if s["pigment"] == pigment and (spectrum_id is None or s["id"] == spectrum_id):
                return s
        raise KeyError(f"no reference spectrum for pigment '{pigment}'")

    # -- rendering
    def _raw(self, rec, wl):
        if "bands" in rec:
            y = np.zeros_like(wl, float)
            for b in rec["bands"]:
                y += gaussian(wl, b["height"], b["centre"], float(fwhm_to_sigma(b["fwhm"])))
            return y
        return np.interp(wl, rec["wavelength"], rec["absorbance"], left=0.0, right=0.0)

    def render(self, wl, pigment, spectrum_id=None):
        rec = self.select(pigment, spectrum_id)
        if "bands" in rec:
            area = trapz(self._raw(rec, _FINE), _FINE)
        else:
            w = np.asarray(rec["wavelength"], float)
            area = trapz(np.asarray(rec["absorbance"], float), w)
        return self._raw(rec, np.asarray(wl, float)) / area

    def matrix(self, wl, pigments, ids=None):
        ids = ids or {}
        return np.column_stack([self.render(wl, p, ids.get(p)) for p in pigments])

    # -- io
    def to_dict(self):
        return {"version": self.version, "description": self.description, "spectra": self.spectra}

    def to_json(self, path=None):
        s = json.dumps(self.to_dict(), indent=1)
        if path:
            Path(path).write_text(s, encoding="utf-8")
        return s

    @classmethod
    def from_json(cls, path_or_text):
        p = str(path_or_text)
        text = Path(p).read_text(encoding="utf-8") if "\n" not in p and Path(p).exists() else p
        d = json.loads(text)
        return cls(d["spectra"], d.get("version", "0.0.0"), d.get("description", ""))

    def add_csv(self, path, **meta):
        """CSV with 'wavelength,absorbance' columns; metadata in '# key: value' comment lines or kwargs."""
        lines = Path(path).read_text(encoding="utf-8").splitlines()
        rec = dict(meta)
        wl, ab = [], []
        for l in lines:
            if l.startswith("#"):
                k, _, v = l[1:].partition(":")
                rec.setdefault(k.strip(), v.strip())
            elif l.strip():
                parts = l.replace(";", ",").split(",")
                try:
                    wl.append(float(parts[0])); ab.append(float(parts[1]))
                except ValueError:
                    continue  # header
        rec["wavelength"], rec["absorbance"] = wl, ab
        rec.setdefault("id", Path(path).stem)
        self.add(rec)

    @classmethod
    def load(cls, path=None):
        """Built-in library, or a .json file, or a directory of .json/.csv files added on top of the built-in one."""
        if path is None:
            return cls.from_json(BUILTIN_PATH)
        p = Path(path)
        if p.is_dir():
            lib = cls.from_json(BUILTIN_PATH)
            for f in sorted(p.glob("*.json")):
                for s in json.loads(f.read_text(encoding="utf-8")).get("spectra", []):
                    s = dict(s)
                    lib.spectra = [x for x in lib.spectra if not (x["pigment"] == s["pigment"] and "bands" in x)] \
                        if s.get("override") else lib.spectra
                    lib.add(s)
            for f in sorted(p.glob("*.csv")):
                lib.add_csv(f)
            return lib
        return cls.from_json(p)


def build_builtin() -> ReferenceLibrary:
    lib = ReferenceLibrary(version="0.1.0", description="Parametric in vivo reference spectra (placeholder for measured spectra).")
    for pig in PIGMENTS:
        lib.add({"id": f"{pig.lower()}_invivo_model", "pigment": pig, "origin": "in vivo (parametric model)",
                 "solvent": None, "method": "Gaussian band model at the in vivo band positions of the project overview",
                 "source": "Project overview band table; NOT a measurement - replace by measured spectra",
                 "bands": [{"centre": c, "fwhm": f, "height": h} for c, f, h in PIGMENT_BANDS[pig]]})
    return lib


_cache = None


def default_library() -> ReferenceLibrary:
    global _cache
    if _cache is None:
        _cache = ReferenceLibrary.load()
    return _cache


if __name__ == "__main__":  # regenerate the shipped JSON
    build_builtin().to_json(BUILTIN_PATH)
