"""Culture-state classification: rule-based baseline, raw-spectrum models, mechanistic-feature models."""
from __future__ import annotations
import numpy as np
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.cross_decomposition import PLSRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupKFold, StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from .pigments import PIGMENTS

RATIO_NAMES = ("PC/Chl", "APC/PC", "Car/Chl", "PBS/Chl")
FEATURE_BANDS = ("Chl_678", "PC_620", "APC_650")


# ------------------------------------------------------------------ rule-based interpreter
DEFAULT_THRESHOLDS = {"car_chl_high": 0.60, "car_chl_low": 0.45, "pc_chl_high": 0.60, "pc_chl_low": 0.30,
                      "pbs_chl_very_low": 0.20, "apc_pc_high": 0.40}


def interpret_ratios(ratios: dict, thresholds=None) -> dict:
    """Transparent rules, no training. Thresholds are uncalibrated defaults: calibrate on your strain/instrument."""
    t = {**DEFAULT_THRESHOLDS, **(thresholds or {})}
    pc, apc, car, pbs = (ratios.get(k, float("nan")) for k in ("PC/Chl", "APC/PC", "Car/Chl", "PBS/Chl"))
    flags = []
    if np.isfinite(pbs) and pbs < t["pbs_chl_very_low"]:
        n_lim = "likely"
        flags.append({"code": "ANTENNA_LOSS", "evidence": {"PBS/Chl": pbs},
                      "message": f"PBS/Chl {pbs:.2f} < {t['pbs_chl_very_low']}: strong phycobilisome degradation (chlorosis, e.g. nitrogen limitation)."})
    elif np.isfinite(pc) and np.isfinite(apc) and pc < t["pc_chl_low"] and apc > t["apc_pc_high"]:
        n_lim = "possible"
        flags.append({"code": "ANTENNA_REDUCED", "evidence": {"PC/Chl": pc, "APC/PC": apc},
                      "message": "Low PC/Chl with high APC/PC: rods shortened relative to the core (nutrient stress or high-light acclimation)."})
    else:
        n_lim = "unlikely"
    if np.isfinite(car) and np.isfinite(pc) and car >= t["car_chl_high"] and pc < t["pc_chl_high"]:
        light = "HL-like"
        flags.append({"code": "HIGH_LIGHT_PATTERN", "evidence": {"Car/Chl": car, "PC/Chl": pc},
                      "message": "High Car/Chl with moderate/low PC/Chl: photoprotective, high-light-like acclimation."})
    elif np.isfinite(car) and np.isfinite(pc) and pc >= t["pc_chl_high"] and car < t["car_chl_low"]:
        light = "LL-like"
        flags.append({"code": "LOW_LIGHT_PATTERN", "evidence": {"Car/Chl": car, "PC/Chl": pc},
                      "message": "High PC/Chl with low Car/Chl: large antenna, low-light-like acclimation."})
    else:
        light = "intermediate/undetermined"
    return {"light_regime": light, "nitrogen_limitation": n_lim, "flags": flags, "thresholds": t,
            "disclaimer": "Rule-based heuristics with uncalibrated default thresholds; not a validated diagnosis."}


# ------------------------------------------------------------------ features
def feature_names():
    return list(RATIO_NAMES) + [f"share:{p}" for p in PIGMENTS] + [f"{k}:{b}" for b in FEATURE_BANDS for k in ("centre", "fwhm")]


def features_from_result(res: dict) -> np.ndarray:
    """Mechanistic feature vector from one deconvolution result (NaN if a band is absent, e.g. NNLS)."""
    f = [res["ratios"].get(r, np.nan) for r in RATIO_NAMES] + [res["pigments"][p]["share"] for p in PIGMENTS]
    bands = {b["name"]: b for b in res.get("bands", [])}
    for b in FEATURE_BANDS:
        for k in ("centre", "fwhm"):
            f.append(bands[b][k] if b in bands else np.nan)
    return np.array(f, float)


def feature_matrix(results: dict, names=None, drop_band_features=False):
    names = names or list(results)
    X = np.array([features_from_result(results[n]) for n in names])
    if drop_band_features:
        X = X[:, : len(RATIO_NAMES) + len(PIGMENTS)]
    return np.nan_to_num(X, nan=0.0), names


# ------------------------------------------------------------------ models
class PLSDA(BaseEstimator, ClassifierMixin):
    """PLS discriminant analysis: PLS regression on one-hot labels, argmax prediction."""

    def __init__(self, n_components=3):
        self.n_components = n_components

    def fit(self, X, y):
        self.classes_ = np.unique(y)
        Y = (np.asarray(y)[:, None] == self.classes_[None, :]).astype(float)
        nc = max(1, min(self.n_components, X.shape[1], X.shape[0] - 1))
        self.pls_ = PLSRegression(n_components=nc, scale=False).fit(X, Y)
        return self

    def predict(self, X):
        return self.classes_[np.argmax(self.pls_.predict(X), axis=1)]


def make_model(kind="plsda", **kw):
    """Scaler + classifier pipeline (scaling is fitted inside each CV fold -> no leakage)."""
    clf = {"plsda": lambda: PLSDA(kw.get("n_components", 3)),
           "logreg": lambda: LogisticRegression(max_iter=2000, C=kw.get("C", 1.0)),
           "rf": lambda: RandomForestClassifier(n_estimators=kw.get("n_estimators", 200), random_state=kw.get("seed", 0))}[kind]()
    return make_pipeline(StandardScaler(), clf)


def cross_validate(model_factory, X, y, groups=None, n_splits=5, seed=0) -> dict:
    """Honest CV: replicates of one culture (groups) are never split across train and test."""
    X, y = np.asarray(X, float), np.asarray(y)
    if groups is not None:
        splits = list(GroupKFold(n_splits=min(n_splits, len(set(groups)))).split(X, y, groups))
    else:
        splits = list(StratifiedKFold(n_splits, shuffle=True, random_state=seed).split(X, y))
    test, train = [], []
    for tr, te in splits:
        m = model_factory().fit(X[tr], y[tr])
        test.append(float(np.mean(m.predict(X[te]) == y[te])))
        train.append(float(np.mean(m.predict(X[tr]) == y[tr])))
    return {"cv_accuracy_mean": float(np.mean(test)), "cv_accuracy_sd": float(np.std(test)),
            "train_accuracy_mean": float(np.mean(train)), "overfit_gap": float(np.mean(train) - np.mean(test)),
            "n_splits": len(splits), "grouped": groups is not None}


def compare_strategies(spectra, labels, groups, results, n_splits=5, seed=0) -> dict:
    """Raw-spectrum models vs mechanistic-feature models, same folds."""
    names = list(spectra["samples"])
    Xraw = np.array([spectra["samples"][n] for n in names])
    Xfeat, _ = feature_matrix(results, names, drop_band_features=True)
    out = {}
    for tag, X in (("raw_spectrum", Xraw), ("features", Xfeat)):
        for kind in ("plsda", "logreg"):
            out[f"{tag}:{kind}"] = cross_validate(lambda: make_model(kind), X, labels, groups, n_splits, seed)
    return out


# ------------------------------------------------------------------ 1D CNN (NumPy inference, optional torch training)
def _conv1d_same(x, w, b):
    n, c, L = x.shape
    o, _, k = w.shape
    xp = np.pad(x, ((0, 0), (0, 0), (k // 2, k - 1 - k // 2)))
    win = np.lib.stride_tricks.sliding_window_view(xp, k, axis=2)  # (n, c, L, k)
    return np.einsum("ncLk,ock->noL", win, w) + b[None, :, None]


def _maxpool(x, p=4):
    L = x.shape[2] // p * p
    return x[:, :, :L].reshape(x.shape[0], x.shape[1], -1, p).max(axis=3)


def cnn1d_forward(weights: dict, X) -> np.ndarray:
    """Pure-NumPy inference of the shipped CNN architecture -> class logits (no DL framework at runtime)."""
    x = (np.asarray(X, float) - weights["x_mean"]) / weights["x_std"]
    x = x[:, None, :]
    x = _maxpool(np.maximum(_conv1d_same(x, weights["conv1_w"], weights["conv1_b"]), 0))
    x = _maxpool(np.maximum(_conv1d_same(x, weights["conv2_w"], weights["conv2_b"]), 0))
    return x.reshape(x.shape[0], -1) @ weights["fc_w"].T + weights["fc_b"]


def cnn1d_predict(weights: dict, X):
    return np.asarray(weights["classes"])[np.argmax(cnn1d_forward(weights, X), axis=1)]


def train_cnn1d(X, y, epochs=200, lr=3e-3, seed=0, channels=(8, 16), kernel=9) -> dict:
    """Train the CNN with PyTorch (optional dependency `pip install cyanospectra[cnn]`) and return NumPy weights."""
    try:
        import torch
        from torch import nn
    except ImportError as e:
        raise ImportError("train_cnn1d needs PyTorch: pip install cyanospectra[cnn]") from e
    torch.manual_seed(seed)
    X = np.asarray(X, float); classes = np.unique(y)
    yi = torch.tensor(np.searchsorted(classes, y))
    mu, sd = X.mean(0), X.std(0) + 1e-8
    xt = torch.tensor(((X - mu) / sd)[:, None, :], dtype=torch.float32)
    L = X.shape[1] // 4 // 4
    net = nn.Sequential(nn.Conv1d(1, channels[0], kernel, padding="same"), nn.ReLU(), nn.MaxPool1d(4),
                        nn.Conv1d(channels[0], channels[1], kernel, padding="same"), nn.ReLU(), nn.MaxPool1d(4),
                        nn.Flatten(), nn.Linear(channels[1] * L, len(classes)))
    opt = torch.optim.Adam(net.parameters(), lr=lr, weight_decay=1e-3)
    for _ in range(epochs):
        opt.zero_grad(); nn.functional.cross_entropy(net(xt), yi).backward(); opt.step()
    p = {k: v.detach().numpy().astype(float) for k, v in net.state_dict().items()}
    return {"conv1_w": p["0.weight"], "conv1_b": p["0.bias"], "conv2_w": p["3.weight"], "conv2_b": p["3.bias"],
            "fc_w": p["7.weight"], "fc_b": p["7.bias"], "x_mean": mu, "x_std": sd, "classes": classes.tolist()}
