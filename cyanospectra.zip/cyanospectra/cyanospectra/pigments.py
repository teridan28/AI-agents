"""Nominal in vivo pigment bands (from the project overview table).

Each band is (centre_nm, fwhm_nm, relative_height). Relative heights only fix the
shape of a pigment inside the model; the absolute amount of a pigment is its total
band area (absorbance * nm).
"""
from __future__ import annotations
import math

PIGMENTS = ("Chl", "Car", "PE", "PC", "APC")
PBS_PIGMENTS = ("PC", "APC", "PE")
LABELS = {"Chl": "Chl a", "Car": "Carotenoids", "PE": "Phycoerythrin",
          "PC": "Phycocyanin", "APC": "Allophycocyanin"}

PIGMENT_BANDS = {
    "Chl": [(435.0, 28.0, 0.85), (678.0, 22.0, 1.00)],
    "Car": [(450.0, 26.0, 0.80), (478.0, 24.0, 1.00), (500.0, 24.0, 0.70)],
    "PE": [(565.0, 40.0, 0.60)],
    "PC": [(620.0, 48.0, 1.00)],
    "APC": [(650.0, 30.0, 1.00)],
}
# bands that may be dropped during model selection
OPTIONAL_BANDS = ("Car_500", "PE_565")


def band_name(pigment: str, centre: float) -> str:
    return f"{pigment}_{int(round(centre))}"


def nominal_bands() -> list:
    """List of band dicts with name, pigment, centre, fwhm, rel_height, area_fraction."""
    out = []
    for pig in PIGMENTS:
        raw = PIGMENT_BANDS[pig]
        areas = [h * f * math.sqrt(math.pi / (4 * math.log(2))) for _, f, h in raw]
        tot = sum(areas)
        for (c, f, h), a in zip(raw, areas):
            out.append({"name": band_name(pig, c), "pigment": pig, "centre": c, "fwhm": f,
                        "rel_height": h, "area_fraction": a / tot})
    out.sort(key=lambda b: b["centre"])
    return out
