"""cyanospectra - analysis and deconvolution of in vivo absorption spectra of cyanobacteria."""
from .parsing import parse_table, parse_pasted, parse_metadata, metadata_from_names
from .qc import run_qc, has_errors
from .preprocessing import preprocess, correct_scattering, smooth, normalise, average_replicates
from .reference import ReferenceLibrary, default_library
from .deconvolution import deconvolve, get_deconvolver, GaussianDeconvolver, NNLSDeconvolver
from .derived import pigment_ratios
from .synthetic import generate_spectrum, generate_dataset
from .benchmark import run_benchmark, run_condition
from .classification import interpret_ratios, compare_strategies, cross_validate, make_model, feature_matrix
from .pipeline import analyze, export_excel, to_json, from_json
from . import viz, agent

__version__ = "0.1.0"
__all__ = [n for n in dir() if not n.startswith("_")]
