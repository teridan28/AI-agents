"""Derived parameters: band parameters and physiological pigment ratios."""
from __future__ import annotations
import math
from .pigments import PIGMENTS

NAN = float("nan")
RATIO_DEFS = {"PC/Chl": ("PC", "Chl"), "APC/PC": ("APC", "PC"), "Car/Chl": ("Car", "Chl"),
              "PBS/Chl": ("PBS", "Chl"), "PE/PC": ("PE", "PC")}


def pigment_ratios(areas: dict) -> dict:
    """Ratios of integrated pigment contributions (areas). PBS = PC + APC + PE."""
    a = {p: float(areas.get(p, 0.0) or 0.0) for p in PIGMENTS}
    a["PBS"] = a["PC"] + a["APC"] + a["PE"]
    out = {}
    for name, (num, den) in RATIO_DEFS.items():
        if name == "PE/PC" and a["PE"] <= 0:
            continue
        out[name] = a[num] / a[den] if a[den] > 0 else NAN
    return out


def derive_parameters(result: dict) -> dict:
    """Band table (area, amplitude, centre, FWHM, share), pigment areas and ratios."""
    return {"bands": result.get("bands", []), "pigments": result["pigments"], "ratios": result["ratios"]}


def flatten_metrics(result: dict) -> dict:
    """Flat {'area:Chl': .., 'ratio:PC/Chl': .., 'centre:Chl_678': ..} used for uncertainty."""
    m = {}
    for p, d in result["pigments"].items():
        m[f"area:{p}"] = d["area"]
    for r, v in result["ratios"].items():
        m[f"ratio:{r}"] = v
    for b in result.get("bands", []):
        m[f"centre:{b['name']}"] = b["centre"]
        m[f"fwhm:{b['name']}"] = b["fwhm"]
        m[f"area:{b['name']}"] = b["area"]
    return m
