"""Two deconvolution methods behind one interface: Gaussian decomposition and NNLS unmixing."""
from __future__ import annotations
import itertools, math
from abc import ABC, abstractmethod
import numpy as np
from scipy.optimize import least_squares, nnls
from ._utils import K_FWHM, fwhm_to_sigma, gaussian, gaussian_area
from .derived import pigment_ratios
from .pigments import PIGMENTS, OPTIONAL_BANDS, nominal_bands
from .preprocessing import REF_WL
from .reference import default_library

B_RANGE = (0.5, 4.0)


def fit_stats(y, fitted, k):
    n = y.size
    rss = float(np.sum((y - fitted) ** 2))
    tss = float(np.sum((y - y.mean()) ** 2))
    ll = n * math.log(max(rss / n, 1e-30))
    return {"r2": 1 - rss / tss if tss > 0 else float("nan"), "rmse": math.sqrt(rss / n), "rss": rss,
            "aic": ll + 2 * k, "bic": ll + k * math.log(n), "n_params": int(k), "n_points": int(n)}


class Deconvolver(ABC):
    """Common interface: fit() returns a JSON-friendly result dict; refit() is used for uncertainty."""
    name = "base"

    @abstractmethod
    def fit(self, wl, y) -> dict: ...

    @abstractmethod
    def refit(self, wl, y, reference_result) -> dict: ...


# ---------------------------------------------------------------- Gaussian decomposition
class GaussianDeconvolver(Deconvolver):
    name = "gaussian"

    def __init__(self, baseline="none", max_shift=5.0, fwhm_range=(0.6, 1.6), include_pe="auto",
                 select_model=True, criterion="bic", bands=None, max_nfev=300):
        if baseline not in ("none", "offset", "power_law"):
            raise ValueError("baseline must be 'none', 'offset' or 'power_law'")
        self.baseline, self.max_shift, self.fwhm_range = baseline, float(max_shift), fwhm_range
        self.include_pe, self.select_model, self.criterion = include_pe, select_model, criterion
        self.bands = [dict(b) for b in (bands or nominal_bands())]
        self.max_nfev = max_nfev

    def _candidates(self):
        names = [b["name"] for b in self.bands]
        pe = {b["name"] for b in self.bands if b["pigment"] == "PE"}
        if not self.select_model:
            return [[n for n in names if not (n in pe and self.include_pe is not True)]]
        opt = [n for n in names if n in OPTIONAL_BANDS and not (n in pe and self.include_pe != "auto")]
        fixed = [n for n in names if n not in opt and not (n in pe and self.include_pe is False)]
        cands = []
        for r in range(len(opt) + 1):
            for sub in itertools.combinations(opt, r):
                keep = set(fixed) | set(sub)
                cands.append([n for n in names if n in keep])
        return sorted(cands, key=len)

    # -- core least-squares fit
    def _fit(self, wl, y, bands, start=None):
        n, ymax = len(bands), max(float(y.max()), 1e-3)
        c0 = np.array([b["centre"] for b in bands]); f0 = np.array([b["fwhm"] for b in bands])
        nb = {"none": 0, "offset": 1, "power_law": 2}[self.baseline]
        lbs = np.concatenate([np.zeros(n), c0 - self.max_shift, f0 * self.fwhm_range[0]])
        ubs = np.concatenate([np.full(n, 2 * ymax), c0 + self.max_shift, f0 * self.fwhm_range[1]])
        if start is None:
            x0 = np.concatenate([np.clip(np.interp(c0, wl, y) * 0.5, 1e-4, ymax), c0, f0])
            tail = float(np.mean(y[-10:]))
            b0 = [] if nb == 0 else ([0.0] if nb == 1 else [max(tail, 1e-3) * (wl[-10:].mean() / REF_WL) ** 1.5, 1.5])
        else:
            x0 = np.concatenate([start["h"], start["c"], start["f"]]); b0 = start["base"]
        if self.baseline == "offset":
            lbs, ubs = np.append(lbs, -ymax), np.append(ubs, ymax)
        elif self.baseline == "power_law":
            lbs, ubs = np.concatenate([lbs, [0.0, B_RANGE[0]]]), np.concatenate([ubs, [5 * ymax + 0.5, B_RANGE[1]]])
        x0 = np.concatenate([x0, b0]) if nb else x0
        eps = 1e-7
        x0 = np.clip(x0, lbs + eps, ubs - eps)
        k = K_FWHM

        def parts(p):
            h, c, f = p[:n], p[n:2 * n], p[2 * n:3 * n]
            s = f / k
            G = h[:, None] * np.exp(-((wl[None, :] - c[:, None]) ** 2) / (2 * s[:, None] ** 2))
            return h, c, f, s, G

        def curve(p):
            if self.baseline == "offset":
                return np.full_like(wl, p[3 * n])
            if self.baseline == "power_law":
                return p[3 * n] * (wl / REF_WL) ** (-p[3 * n + 1])
            return np.zeros_like(wl)

        def resid(p):
            return y - (parts(p)[4].sum(0) + curve(p))

        def jac(p):
            h, c, f, s, G = parts(p)
            d = wl[None, :] - c[:, None]
            J = np.zeros((wl.size, 3 * n + nb))
            J[:, :n] = (G / np.where(h > 0, h, 1)[:, None]).T if np.all(h > 0) else \
                np.exp(-(d ** 2) / (2 * s[:, None] ** 2)).T
            J[:, n:2 * n] = (G * d / s[:, None] ** 2).T
            J[:, 2 * n:3 * n] = (G * d ** 2 / s[:, None] ** 3 / k).T
            if self.baseline == "offset":
                J[:, 3 * n] = 1.0
            elif self.baseline == "power_law":
                u = (wl / REF_WL) ** (-p[3 * n + 1])
                J[:, 3 * n] = u
                J[:, 3 * n + 1] = -p[3 * n] * u * np.log(wl / REF_WL)
            return -J

        r = least_squares(resid, x0, jac=jac, bounds=(lbs, ubs), x_scale="jac", max_nfev=self.max_nfev)
        p = r.x
        return {"h": p[:n], "c": p[n:2 * n], "f": p[2 * n:3 * n], "base": p[3 * n:], "fitted": y - r.fun,
                "lb": lbs, "ub": ubs, "p": p}

    def _assemble(self, wl, y, bands, fit, selection=None):
        n = len(bands)
        sig = fit["f"] / K_FWHM
        out_bands, comps, warns = [], {}, []
        for i, b in enumerate(bands):
            area = gaussian_area(fit["h"][i], sig[i])
            out_bands.append({"name": b["name"], "pigment": b["pigment"], "centre": float(fit["c"][i]),
                              "fwhm": float(fit["f"][i]), "height": float(fit["h"][i]), "area": float(area)})
            comps[b["name"]] = gaussian(wl, fit["h"][i], fit["c"][i], sig[i])
            for what, v, j in (("centre", fit["c"][i], n + i), ("fwhm", fit["f"][i], 2 * n + i)):
                if abs(v - fit["lb"][j]) < 1e-3 * max(1, abs(v)) or abs(v - fit["ub"][j]) < 1e-3 * max(1, abs(v)):
                    warns.append({"code": "BOUND_HIT", "message": f"{b['name']}: {what} at its bound ({v:.1f})"})
        total = sum(b["area"] for b in out_bands) or float("nan")
        for b in out_bands:
            b["share"] = b["area"] / total
        areas = {p: sum(b["area"] for b in out_bands if b["pigment"] == p) for p in PIGMENTS}
        tot_p = sum(areas.values()) or float("nan")
        base_curve = fit["fitted"] - sum(comps.values())
        bp = {}
        if self.baseline == "offset":
            bp = {"offset": float(fit["base"][0])}
        elif self.baseline == "power_law":
            bp = {"a500": float(fit["base"][0]), "b": float(fit["base"][1])}
        k = 3 * n + len(fit["base"])
        res = {"method": "gaussian", "wavelength": wl, "observed": y, "fitted": fit["fitted"],
               "residual": y - fit["fitted"], "baseline": base_curve, "baseline_params": bp,
               "components": comps, "bands": out_bands,
               "pigments": {p: {"area": areas[p], "share": areas[p] / tot_p} for p in PIGMENTS},
               "ratios": pigment_ratios(areas), "fit": fit_stats(y, fit["fitted"], k),
               "model": {"bands": [b["name"] for b in bands], "baseline": self.baseline},
               "model_selection": selection or [], "warnings": warns}
        return res

    def fit(self, wl, y):
        wl, y = np.asarray(wl, float), np.asarray(y, float)
        trials = []
        for names in self._candidates():
            bands = [b for b in self.bands if b["name"] in names]
            f = self._fit(wl, y, bands)
            trials.append((names, bands, f, fit_stats(y, f["fitted"], 3 * len(bands) + len(f["base"]))))
        best = min(range(len(trials)), key=lambda i: trials[i][3][self.criterion])
        sel = [{"model": "+".join(t[0]), "n_bands": len(t[0]), "aic": t[3]["aic"], "bic": t[3]["bic"],
                "rss": t[3]["rss"], "selected": i == best} for i, t in enumerate(trials)]
        return self._assemble(wl, y, trials[best][1], trials[best][2], sel)

    def refit(self, wl, y, ref):
        wl, y = np.asarray(wl, float), np.asarray(y, float)
        names = ref["model"]["bands"]
        bands = [next(b for b in self.bands if b["name"] == nm) for nm in names]
        by = {b["name"]: b for b in ref["bands"]}
        base = [] if self.baseline == "none" else list(ref["baseline_params"].values())
        start = {"h": np.array([by[nm]["height"] for nm in names]), "c": np.array([by[nm]["centre"] for nm in names]),
                 "f": np.array([by[nm]["fwhm"] for nm in names]), "base": np.array(base)}
        return self._assemble(wl, y, bands, self._fit(wl, y, bands, start))


# ---------------------------------------------------------------- NNLS unmixing
class NNLSDeconvolver(Deconvolver):
    name = "nnls"

    def __init__(self, library=None, pigments=None, reference_ids=None, baseline="none", include_pe="auto",
                 select_model=True, criterion="bic"):
        if baseline not in ("none", "offset", "power_law"):
            raise ValueError("baseline must be 'none', 'offset' or 'power_law'")
        self.lib = library or default_library()
        self.pigments = list(pigments or self.lib.pigments())
        self.ids, self.baseline = reference_ids or {}, baseline
        self.include_pe, self.select_model, self.criterion = include_pe, select_model, criterion

    def _solve(self, wl, y, pigs):
        A = self.lib.matrix(wl, pigs, self.ids)
        best = None
        if self.baseline == "power_law":
            options = [(b, (wl / REF_WL) ** (-b)) for b in np.arange(B_RANGE[0], B_RANGE[1] + 1e-9, 0.25)]
        elif self.baseline == "offset":
            options = [(None, np.ones_like(wl))]
        else:
            options = [(None, None)]
        for b, col in options:
            M = A if col is None else np.column_stack([A, col])
            w, _ = nnls(M, y)
            fit = M @ w
            rss = float(np.sum((y - fit) ** 2))
            if best is None or rss < best["rss"]:
                best = {"w": w[:len(pigs)], "base_w": float(w[-1]) if col is not None else 0.0, "b": b,
                        "fitted": fit, "rss": rss, "A": A, "col": col}
        return best

    def _assemble(self, wl, y, pigs, s, selection=None):
        comps = {p: s["w"][i] * s["A"][:, i] for i, p in enumerate(pigs)}
        areas = {p: (float(s["w"][pigs.index(p)]) if p in pigs else 0.0) for p in PIGMENTS}
        tot = sum(areas.values()) or float("nan")
        base = s["base_w"] * s["col"] if s["col"] is not None else np.zeros_like(wl)
        bp = {}
        if self.baseline == "offset":
            bp = {"offset": s["base_w"]}
        elif self.baseline == "power_law":
            bp = {"a500": s["base_w"], "b": float(s["b"])}
        k = int(np.sum(s["w"] > 1e-12)) + (0 if self.baseline == "none" else len(bp) if self.baseline == "power_law" else 1)
        return {"method": "nnls", "wavelength": wl, "observed": y, "fitted": s["fitted"],
                "residual": y - s["fitted"], "baseline": base, "baseline_params": bp, "components": comps,
                "bands": [], "pigments": {p: {"area": areas[p], "share": areas[p] / tot} for p in PIGMENTS},
                "ratios": pigment_ratios(areas), "fit": fit_stats(y, s["fitted"], k),
                "model": {"pigments": list(pigs), "baseline": self.baseline, "library_version": self.lib.version},
                "model_selection": selection or [], "warnings": []}

    def _candidates(self):
        base = [p for p in self.pigments if not (p == "PE" and self.include_pe is False)]
        if "PE" in base and self.include_pe == "auto" and self.select_model:
            return [[p for p in base if p != "PE"], base]
        if "PE" in base and self.include_pe == "auto":
            return [[p for p in base if p != "PE"]]
        return [base]

    def fit(self, wl, y):
        wl, y = np.asarray(wl, float), np.asarray(y, float)
        trials = []
        for pigs in self._candidates():
            s = self._solve(wl, y, pigs)
            k = int(np.sum(s["w"] > 1e-12)) + (0 if self.baseline == "none" else 1)
            trials.append((pigs, s, fit_stats(y, s["fitted"], k)))
        best = min(range(len(trials)), key=lambda i: trials[i][2][self.criterion])
        sel = [{"model": "+".join(t[0]), "n_bands": len(t[0]), "aic": t[2]["aic"], "bic": t[2]["bic"],
                "rss": t[2]["rss"], "selected": i == best} for i, t in enumerate(trials)]
        return self._assemble(wl, y, trials[best][0], trials[best][1], sel)

    def refit(self, wl, y, ref):
        wl, y = np.asarray(wl, float), np.asarray(y, float)
        pigs = ref["model"]["pigments"]
        return self._assemble(wl, y, pigs, self._solve(wl, y, pigs))


METHODS = {"gaussian": GaussianDeconvolver, "nnls": NNLSDeconvolver}


def get_deconvolver(method="gaussian", **options) -> Deconvolver:
    if method not in METHODS:
        raise ValueError(f"unknown method '{method}', choose from {sorted(METHODS)}")
    return METHODS[method](**options)


def deconvolve(wl, y, method="gaussian", uncertainty=None, **options) -> dict:
    """Fit one spectrum. uncertainty={'method': 'bootstrap'|'monte_carlo', 'n': 50, 'seed': 0}."""
    from .uncertainty import estimate_uncertainty
    dec = get_deconvolver(method, **options)
    wl, y = np.asarray(wl, float), np.asarray(y, float)
    res = dec.fit(wl, y)
    if uncertainty and uncertainty.get("n", 0) > 0:
        res["uncertainty"] = estimate_uncertainty(dec, wl, y, res, **uncertainty)
    return res
