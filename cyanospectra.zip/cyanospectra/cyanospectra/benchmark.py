"""Benchmark of the deconvolution methods against synthetic ground truth."""
from __future__ import annotations
import numpy as np
from .synthetic import generate_spectrum, DEFAULT_COMPOSITION
from .preprocessing import correct_scattering
from .deconvolution import deconvolve

RATIOS = ("PC/Chl", "APC/PC", "Car/Chl", "PBS/Chl")
SCATTER_MODES = ("oracle:0", "oracle:+0.1", "oracle:-0.1", "oracle:+0.3", "nir_fit", "joint")


def _random_composition(rng):
    chl = 20.0 * rng.lognormal(0, 0.2)
    pc = chl * rng.uniform(0.25, 0.9)
    return {"Chl": chl, "Car": chl * rng.uniform(0.3, 0.8), "PC": pc, "APC": pc * rng.uniform(0.15, 0.4), "PE": 0.0}


def _prepare(s, mode):
    """Apply a scattering strategy; returns (wl, y, deconvolution options)."""
    wl, y = s["wavelength"], s["absorbance"]
    if mode.startswith("oracle:"):
        e = float(mode.split(":")[1])
        return wl, y - (1 + e) * s["truth"]["scattering"], {}
    if mode == "nir_fit":
        sp, _ = correct_scattering({"wavelength": wl, "samples": {"x": y}}, "power_law")
        return wl, sp["samples"]["x"], {}
    if mode == "joint":
        return wl, y, {"baseline": "power_law"}
    raise ValueError(mode)


def run_condition(noise_sd=0.002, overlap_scale=1.0, scatter_mode="oracle:0", n_rep=5, seed=0,
                  methods=("gaussian", "nnls"), centre_jitter=1.0, fwhm_jitter=0.04) -> dict:
    rng = np.random.default_rng(seed)
    errs = {m: {r: [] for r in RATIOS} for m in methods}
    for i in range(n_rep):
        s = generate_spectrum(_random_composition(rng), noise_sd=noise_sd, overlap_scale=overlap_scale,
                              scatter={"a500": rng.uniform(0.06, 0.2), "b": rng.uniform(1.0, 2.5)},
                              centre_jitter=centre_jitter, fwhm_jitter=fwhm_jitter, seed=int(rng.integers(1 << 31)))
        wl, y, opt = _prepare(s, scatter_mode)
        for m in methods:
            try:
                r = deconvolve(wl, y, m, **opt)["ratios"]
            except Exception:
                r = {}
            for k in RATIOS:
                t, v = s["truth"]["ratios"][k], r.get(k, float("nan"))
                errs[m][k].append(abs(v - t) / t if np.isfinite(v) else float("nan"))
    out = {}
    for m in methods:
        allv = np.array([v for k in RATIOS for v in errs[m][k]], float)
        out[m] = {"median_rel_error": float(np.nanmedian(allv)), "max_rel_error": float(np.nanmax(allv)) if np.isfinite(allv).any() else float("nan"),
                  "per_ratio_median": {k: float(np.nanmedian(errs[m][k])) for k in RATIOS},
                  "failure_rate_25pct": float(np.mean(~(allv < 0.25)))}
    return {"noise_sd": noise_sd, "overlap_scale": overlap_scale, "scatter_mode": scatter_mode, "n_rep": n_rep, "methods": out}


def run_benchmark(noise_levels=(0.001, 0.003, 0.01), overlap_scales=(1.0, 1.15, 1.3),
                  scatter_modes=SCATTER_MODES, n_rep=5, seed=0, methods=("gaussian", "nnls")) -> dict:
    """One-factor-at-a-time sweeps over noise, band overlap and scattering-correction error."""
    sweeps = {"noise": [run_condition(noise_sd=v, n_rep=n_rep, seed=seed, methods=methods) for v in noise_levels],
              "overlap": [run_condition(overlap_scale=v, n_rep=n_rep, seed=seed, methods=methods) for v in overlap_scales],
              "scatter": [run_condition(scatter_mode=v, n_rep=n_rep, seed=seed, methods=methods) for v in scatter_modes]}
    summary = {}
    for m in methods:
        vals = [c["methods"][m]["median_rel_error"] for sw in sweeps.values() for c in sw]
        summary[m] = {"mean_of_median_rel_errors": float(np.mean(vals))}
    best = min(summary, key=lambda m: summary[m]["mean_of_median_rel_errors"])
    return {"sweeps": sweeps, "summary": summary, "best_method": best, "n_rep": n_rep, "seed": seed}
