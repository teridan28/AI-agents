from __future__ import annotations
import math, re
from pathlib import Path
import numpy as np

K_FWHM = 2.0 * math.sqrt(2.0 * math.log(2.0))  # FWHM = K_FWHM * sigma


def fwhm_to_sigma(f):
    return np.asarray(f, float) / K_FWHM


def gaussian(x, h, c, sigma):
    return h * np.exp(-((x - c) ** 2) / (2.0 * sigma ** 2))


def gaussian_area(h, sigma):
    return h * sigma * math.sqrt(2.0 * math.pi)


def trapz(y, x) -> float:
    f = np.trapezoid if hasattr(np, "trapezoid") else np.trapz
    return float(f(y, x))


def estimate_noise_sd(y) -> float:
    """Robust white-noise estimate from the second difference (var(d2) = 6 sigma^2)."""
    y = np.asarray(y, float)
    y = y[np.isfinite(y)]
    if y.size < 5:
        return float("nan")
    d2 = y[2:] - 2 * y[1:-1] + y[:-2]
    mad = np.median(np.abs(d2 - np.median(d2)))
    return float(1.4826 * mad / math.sqrt(6))


_REP = re.compile(r"[_\-\s.]+(?:rep|r)?\d+$|rep\d+$", re.I)


def group_of(name: str) -> str:
    """Replicate group of a sample name: 'WT_LL_rep2' -> 'WT_LL'."""
    g = _REP.sub("", str(name))
    return g if g else str(name)


def to_jsonable(o):
    if isinstance(o, dict):
        return {str(k): to_jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [to_jsonable(v) for v in o]
    if isinstance(o, np.ndarray):
        return to_jsonable(o.tolist())
    if isinstance(o, np.generic):
        return to_jsonable(o.item())
    if isinstance(o, float):
        return o if math.isfinite(o) else None
    if isinstance(o, Path):
        return str(o)
    return o


def as_spectra(obj) -> dict:
    """Normalise a spectra container: {'wavelength': array, 'samples': {name: array}}."""
    wl = np.asarray(obj["wavelength"], float)
    samples = {str(k): np.asarray(v, float) for k, v in obj["samples"].items()}
    for k, v in samples.items():
        if v.shape != wl.shape:
            raise ValueError(f"sample '{k}' has {v.size} points, wavelength has {wl.size}")
    out = dict(obj)
    out["wavelength"], out["samples"] = wl, samples
    return out
