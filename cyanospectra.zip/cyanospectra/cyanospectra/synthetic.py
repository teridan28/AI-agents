"""Seeded generator of synthetic whole-cell spectra with known ground truth."""
from __future__ import annotations
import numpy as np
from ._utils import fwhm_to_sigma, gaussian
from .pigments import nominal_bands, PIGMENTS
from .derived import pigment_ratios

DEFAULT_WAVELENGTH = np.arange(400.0, 751.0)
# total band area per pigment (absorbance * nm); gives PC/Chl~0.52, APC/PC~0.26, Car/Chl~0.59
DEFAULT_COMPOSITION = {"Chl": 20.0, "Car": 11.8, "PC": 10.4, "APC": 2.7, "PE": 0.0}
DEFAULT_SCATTER = {"a500": 0.12, "b": 1.5}   # A_scat = a500 * (lambda/500)^-b


def generate_spectrum(composition=None, wavelength=None, noise_sd=0.002, scatter=None,
                      centre_jitter=0.0, fwhm_jitter=0.0, overlap_scale=1.0, seed=0) -> dict:
    """Generate one spectrum. Returns {'wavelength','absorbance','truth'}.

    centre_jitter (nm) / fwhm_jitter (relative) perturb the true bands relative to the
    nominal ones (so a reference library is never a perfect match, as with real data).
    overlap_scale > 1 widens all bands (more overlap).
    """
    rng = np.random.default_rng(seed)
    wl = DEFAULT_WAVELENGTH.copy() if wavelength is None else np.asarray(wavelength, float)
    comp = {**DEFAULT_COMPOSITION, **(composition or {})}
    sc = {**DEFAULT_SCATTER, **(scatter or {})}
    clean = np.zeros_like(wl)
    bands = []
    for b in nominal_bands():
        area = comp[b["pigment"]] * b["area_fraction"]
        if area <= 0:
            continue
        c = b["centre"] + rng.normal(0, centre_jitter) if centre_jitter else b["centre"]
        f = b["fwhm"] * overlap_scale * ((1 + rng.normal(0, fwhm_jitter)) if fwhm_jitter else 1)
        f = max(f, 5.0)
        sigma = float(fwhm_to_sigma(f))
        h = area / (sigma * np.sqrt(2 * np.pi))
        clean += gaussian(wl, h, c, sigma)
        bands.append({"name": b["name"], "pigment": b["pigment"], "centre": c, "fwhm": f,
                      "height": h, "area": area})
    scat = sc["a500"] * (wl / 500.0) ** (-sc["b"])
    noise = rng.normal(0, noise_sd, wl.size) if noise_sd else np.zeros_like(wl)
    areas = {p: comp[p] for p in PIGMENTS}
    truth = {"composition": areas, "ratios": pigment_ratios(areas), "bands": bands,
             "scatter": sc, "noise_sd": noise_sd, "clean": clean, "scattering": scat}
    return {"wavelength": wl, "absorbance": clean + scat + noise, "truth": truth}


# (PC/Chl, APC/PC, Car/Chl) per class -- illustrative, NOT calibrated on real cultures
CLASS_RATIOS = {"LL": (0.75, 0.28, 0.35), "HL": (0.40, 0.30, 0.75), "N_lim": (0.12, 0.45, 0.55)}


def generate_dataset(classes=None, n_cultures=8, n_rep=3, noise_sd=0.002, centre_jitter=1.0,
                     fwhm_jitter=0.04, ratio_cv=0.12, seed=0) -> dict:
    """Synthetic labelled dataset: classes x cultures x replicates (replicates share a culture)."""
    rng = np.random.default_rng(seed)
    classes = classes or CLASS_RATIOS
    wl = DEFAULT_WAVELENGTH.copy()
    samples, meta, truth = {}, {}, {}
    for cls, (pc, apc, car) in classes.items():
        for i in range(n_cultures):
            chl = 20.0 * rng.lognormal(0, 0.25)
            pc_a = chl * pc * rng.lognormal(0, ratio_cv)
            comp = {"Chl": chl, "Car": chl * car * rng.lognormal(0, ratio_cv), "PC": pc_a,
                    "APC": pc_a * apc * rng.lognormal(0, ratio_cv), "PE": 0.0}
            scat = {"a500": rng.uniform(0.06, 0.2), "b": rng.uniform(1.0, 2.5)}
            group = f"{cls}_c{i + 1}"
            for r in range(n_rep):
                s = generate_spectrum(comp, wl, noise_sd, scat, centre_jitter, fwhm_jitter,
                                      seed=int(rng.integers(1 << 31)))
                name = f"{group}_rep{r + 1}"
                samples[name] = s["absorbance"]
                meta[name] = {"class": cls, "group": group, "replicate": r + 1}
                truth[name] = s["truth"]
    return {"spectra": {"wavelength": wl, "samples": samples}, "metadata": meta, "truth": truth,
            "labels": [meta[k]["class"] for k in samples], "groups": [meta[k]["group"] for k in samples]}
