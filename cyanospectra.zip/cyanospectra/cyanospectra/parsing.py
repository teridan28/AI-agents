"""Parsing of spectra from Excel files, delimited text and text pasted from a spreadsheet."""
from __future__ import annotations
import io, math, re
from pathlib import Path
import numpy as np
import pandas as pd

NAN = float("nan")


def _to_float(s) -> float:
    s = str(s).strip().replace("\u00a0", "")
    if s == "" or s.lower() == "nan":
        return NAN
    try:
        return float(s.replace(",", "."))
    except ValueError:
        return NAN


def _detect_delimiter(lines):
    sample = lines[:30]
    if any("\t" in l for l in sample):
        return "\t"
    if any(";" in l for l in sample):
        return ";"
    if any("," in l for l in sample):
        # comma is a delimiter only if every non-header line splits into plain floats
        ok = True
        for l in sample[1:] if len(sample) > 1 else sample:
            for tok in l.split(","):
                try:
                    float(tok)
                except ValueError:
                    ok = False
        if ok:
            return ","
    return None  # whitespace (decimal comma allowed)


def _unique(names):
    seen, out = {}, []
    for n in names:
        n = str(n).strip() or "sample"
        if n in seen:
            seen[n] += 1
            n = f"{n}_{seen[n]}"
        else:
            seen[n] = 1
        out.append(n)
    return out


def _build(wl, data, names, step=1.0) -> dict:
    """Sort, drop duplicate wavelengths, and resample all columns onto a shared integer grid."""
    wl = np.asarray(wl, float)
    data = np.asarray(data, float)
    keep = np.isfinite(wl)
    wl, data = wl[keep], data[keep]
    order = np.argsort(wl, kind="stable")
    wl, data = wl[order], data[order]
    _, idx = np.unique(wl, return_index=True)
    wl, data = wl[idx], data[idx]
    lo, hi = -np.inf, np.inf
    for j in range(data.shape[1]):
        valid = np.isfinite(data[:, j])
        if valid.sum() < 2:
            raise ValueError(f"column '{names[j]}' has fewer than 2 numeric values")
        lo, hi = max(lo, wl[valid][0]), min(hi, wl[valid][-1])
    if hi <= lo:
        raise ValueError("columns share no common wavelength range")
    grid = np.arange(math.ceil(lo / step) * step, math.floor(hi / step) * step + step / 2, step)
    samples = {}
    for j, n in enumerate(names):
        valid = np.isfinite(data[:, j])
        samples[n] = np.interp(grid, wl[valid], data[valid, j])
    return {"wavelength": grid, "samples": samples, "metadata": {},
            "source": {"n_raw_points": int(wl.size), "raw_range": [float(wl[0]), float(wl[-1])]}}


def _from_dataframe(df: pd.DataFrame, step=1.0) -> dict:
    df = df.dropna(how="all").dropna(axis=1, how="all")
    if df.shape[1] < 2:
        raise ValueError("need a wavelength column and at least one sample column")

    def conv(col):
        return col.map(lambda v: _to_float(v) if isinstance(v, str) else v).astype(float)

    wl = conv(df.iloc[:, 0]).to_numpy()
    data = np.column_stack([conv(df.iloc[:, j]).to_numpy() for j in range(1, df.shape[1])])
    return _build(wl, data, _unique(df.columns[1:]), step)


def parse_pasted(text: str, step: float = 1.0) -> dict:
    """Parse text copied from a spreadsheet or a delimited file.

    Delimiter (tab, ';', ',', whitespace) and decimal separator (',' or '.') are detected.
    The first column is wavelength (nm); a header row is optional.
    """
    lines = [l for l in text.replace("\r\n", "\n").replace("\r", "\n").split("\n") if l.strip()]
    if not lines:
        raise ValueError("empty input")
    delim = _detect_delimiter(lines)
    rows = [[c.strip() for c in (l.split(delim) if delim else l.split())] for l in lines]
    header = None
    if math.isnan(_to_float(rows[0][0])):
        header, rows = rows[0], rows[1:]
    if not rows:
        raise ValueError("no data rows")
    ncol = max(len(r) for r in rows)
    arr = np.full((len(rows), ncol), NAN)
    for i, r in enumerate(rows):
        for j, c in enumerate(r):
            arr[i, j] = _to_float(c)
    if ncol < 2:
        raise ValueError("need a wavelength column and at least one sample column")
    if header is None:
        names = [f"Sample_{j}" for j in range(1, ncol)]
    elif len(header) == ncol:
        names = header[1:]
    elif len(header) == ncol - 1:
        names = header
    else:
        names = (header[1:] + [f"Sample_{j}" for j in range(len(header), ncol)])[: ncol - 1]
    return _build(arr[:, 0], arr[:, 1:], _unique(names), step)


def _decode(b: bytes) -> str:
    for enc in ("utf-8-sig", "utf-16", "latin-1"):
        try:
            return b.decode(enc)
        except UnicodeError:
            continue
    return b.decode("latin-1", "replace")


def parse_table(source, sheet_name=0, step: float = 1.0) -> dict:
    """Parse a path (.xlsx/.xls/.csv/.txt/.tsv), raw bytes, a DataFrame or pasted text."""
    if isinstance(source, pd.DataFrame):
        return _from_dataframe(source, step)
    if isinstance(source, (bytes, bytearray)):
        b = bytes(source)
        if b[:2] == b"PK" or b[:4] == b"\xd0\xcf\x11\xe0":
            return _from_dataframe(pd.read_excel(io.BytesIO(b), sheet_name=sheet_name), step)
        return parse_pasted(_decode(b), step)
    if isinstance(source, Path) or (isinstance(source, str) and "\n" not in source and len(source) < 1024
                                    and Path(source).exists()):
        p = Path(source)
        if p.suffix.lower() in (".xlsx", ".xlsm", ".xls"):
            return _from_dataframe(pd.read_excel(p, sheet_name=sheet_name), step)
        return parse_pasted(_decode(p.read_bytes()), step)
    if isinstance(source, str):
        return parse_pasted(source, step)
    raise TypeError(f"unsupported source type: {type(source)!r}")


def parse_metadata(source) -> dict:
    """Metadata table (first column = sample name) -> {sample: {column: value}}."""
    if isinstance(source, dict):
        return {str(k): dict(v) for k, v in source.items()}
    if isinstance(source, pd.DataFrame):
        df = source
    elif isinstance(source, (str, Path)) and "\n" not in str(source) and Path(str(source)).exists():
        p = Path(str(source))
        df = pd.read_excel(p) if p.suffix.lower() in (".xlsx", ".xls") else pd.read_csv(p, sep=None, engine="python")
    else:
        df = pd.read_csv(io.StringIO(str(source)), sep=None, engine="python")
    key = df.columns[0]
    out = {}
    for _, row in df.iterrows():
        out[str(row[key])] = {c: (None if pd.isna(row[c]) else (row[c].item() if hasattr(row[c], "item") else row[c]))
                              for c in df.columns[1:]}
    return out


def metadata_from_names(names, fields=("strain", "light", "replicate"), sep="_") -> dict:
    """Derive metadata from sample names such as 'WT_LL_rep1'."""
    out = {}
    for n in names:
        parts = str(n).split(sep)
        out[str(n)] = {f: (parts[i] if i < len(parts) else None) for i, f in enumerate(fields)}
    return out
