"""Figures. Every function returns a matplotlib Figure; none calls show() or savefig()."""
from __future__ import annotations
import numpy as np
from matplotlib.figure import Figure
from scipy.signal import savgol_filter
from ._utils import as_spectra
from .pigments import LABELS

COLORS = {"Chl": "#2e8b57", "Car": "#e0a100", "PC": "#3b7dd8", "APC": "#8e5bd0", "PE": "#d6455d"}


def _pick(sp, samples):
    sp = as_spectra(sp)
    names = samples or list(sp["samples"])
    return sp["wavelength"], {n: sp["samples"][n] for n in names}


def plot_spectra(spectra, samples=None, title="Absorption spectra") -> Figure:
    wl, S = _pick(spectra, samples)
    fig = Figure(figsize=(7, 4)); ax = fig.subplots()
    for n, y in S.items():
        ax.plot(wl, y, lw=1.2, label=n)
    ax.set(xlabel="Wavelength (nm)", ylabel="Absorbance", title=title)
    if len(S) <= 12:
        ax.legend(fontsize=7)
    fig.tight_layout()
    return fig


def plot_overlay(curves: dict, title="Overlay") -> Figure:
    """curves: {label: (wavelength, values)} e.g. raw vs corrected."""
    fig = Figure(figsize=(7, 4)); ax = fig.subplots()
    for k, (x, y) in curves.items():
        ax.plot(x, y, lw=1.2, label=k)
    ax.set(xlabel="Wavelength (nm)", ylabel="Absorbance", title=title); ax.legend(fontsize=8)
    fig.tight_layout()
    return fig


def plot_difference(spectra, sample_a, sample_b) -> Figure:
    sp = as_spectra(spectra)
    fig = Figure(figsize=(7, 3.5)); ax = fig.subplots()
    ax.plot(sp["wavelength"], sp["samples"][sample_a] - sp["samples"][sample_b], lw=1.2)
    ax.axhline(0, color="k", lw=0.6)
    ax.set(xlabel="Wavelength (nm)", ylabel="\u0394 absorbance", title=f"{sample_a} \u2212 {sample_b}")
    fig.tight_layout()
    return fig


def plot_derivative(spectra, order=2, window=15, samples=None) -> Figure:
    """2nd / 4th derivative spectra (Savitzky-Golay) to reveal hidden overlapping bands."""
    if order not in (1, 2, 3, 4):
        raise ValueError("order must be 1-4")
    wl, S = _pick(spectra, samples)
    window = max(int(window) | 1, order + 3 | 1)
    fig = Figure(figsize=(7, 4)); ax = fig.subplots()
    for n, y in S.items():
        ax.plot(wl, savgol_filter(y, window, max(order + 1, 4 if order > 2 else 3), deriv=order, delta=float(np.mean(np.diff(wl)))), lw=1.1, label=n)
    ax.axhline(0, color="k", lw=0.5)
    ax.set(xlabel="Wavelength (nm)", ylabel=f"d{order}A/d\u03bb{order}", title=f"Derivative spectra (order {order})")
    if len(S) <= 12:
        ax.legend(fontsize=7)
    fig.tight_layout()
    return fig


def plot_deconvolution(result: dict, title=None) -> Figure:
    """Observed, fit, individual contributions and baseline (top); residual (bottom)."""
    wl = np.asarray(result["wavelength"]); y = np.asarray(result["observed"])
    fig = Figure(figsize=(7.5, 5.5))
    ax, ar = fig.subplots(2, 1, sharex=True, gridspec_kw={"height_ratios": [3, 1]})
    base = np.asarray(result["baseline"])
    ax.plot(wl, y, "k-", lw=1.2, label="observed")
    ax.plot(wl, result["fitted"], "k--", lw=1.0, label="fit")
    if np.any(base):
        ax.plot(wl, base, color="grey", lw=1, ls=":", label="scattering/baseline")
    done = set()
    for name, comp in result["components"].items():
        pig = name.split("_")[0]
        ax.fill_between(wl, base, base + np.asarray(comp), color=COLORS.get(pig, "grey"), alpha=0.35,
                        label=LABELS.get(pig, pig) if pig not in done else None)
        done.add(pig)
    ax.set(ylabel="Absorbance", title=title or f"{result['method']} deconvolution  (R\u00b2={result['fit']['r2']:.4f})")
    ax.legend(fontsize=7, ncol=2)
    ar.plot(wl, result["residual"], color="#c0392b", lw=0.9); ar.axhline(0, color="k", lw=0.5)
    ar.set(xlabel="Wavelength (nm)", ylabel="Residual")
    fig.tight_layout()
    return fig


def plot_benchmark(bench: dict) -> Figure:
    fig = Figure(figsize=(11, 3.6)); axes = fig.subplots(1, 3)
    keys = {"noise": "noise_sd", "overlap": "overlap_scale", "scatter": "scatter_mode"}
    for ax, (sw, key) in zip(axes, keys.items()):
        conds = bench["sweeps"][sw]
        x = np.arange(len(conds))
        for m in conds[0]["methods"]:
            ax.plot(x, [c["methods"][m]["median_rel_error"] for c in conds], "o-", label=m)
        ax.set_xticks(x); ax.set_xticklabels([str(c[key]) for c in conds], rotation=30, fontsize=7)
        ax.set(title=f"vs {sw}", ylabel="median relative error"); ax.axhline(0.25, color="grey", ls=":", lw=0.8)
    axes[0].legend(fontsize=8)
    fig.tight_layout()
    return fig
