"""Quality control: structured findings (code, severity, message), never printed warnings."""
from __future__ import annotations
import numpy as np
from ._utils import as_spectra, estimate_noise_sd, group_of


def _f(code, severity, message, sample=None, value=None):
    return {"code": code, "severity": severity, "message": message, "sample": sample, "value": value}


def run_qc(spectra, saturation=1.5, noise_warn=0.005, min_span=200.0, groups=None, outlier_factor=3.0) -> list:
    sp = as_spectra(spectra)
    wl, S = sp["wavelength"], sp["samples"]
    out = []
    span = float(wl.max() - wl.min())
    if span < min_span:
        out.append(_f("NARROW_RANGE", "error", f"Wavelength span {span:.0f} nm is below {min_span:.0f} nm; "
                      "deconvolution is not meaningful.", value=span))
    elif wl.min() > 420 or wl.max() < 700:
        out.append(_f("NARROW_RANGE", "warning", f"Range {wl.min():.0f}-{wl.max():.0f} nm does not cover "
                      "400-700 nm; some pigment bands are missing.", value=[float(wl.min()), float(wl.max())]))
    if wl.max() < 730:
        out.append(_f("NO_NIR_BASELINE", "warning", "Spectrum ends below 730 nm: scattering cannot be "
                      "estimated from the near-infrared region; use baseline='power_law' in the fit."))
    for n, y in S.items():
        if not np.all(np.isfinite(y)):
            out.append(_f("NAN_VALUES", "error", f"{n}: contains non-finite values.", n))
            continue
        if y.max() > saturation:
            out.append(_f("SATURATION", "error", f"{n}: maximum absorbance {y.max():.2f} exceeds {saturation}; "
                          "detector may be saturated, dilute the sample.", n, float(y.max())))
        if y.min() < -0.01:
            out.append(_f("NEGATIVE_VALUES", "warning", f"{n}: negative absorbance (min {y.min():.3f}); "
                          "check the blank.", n, float(y.min())))
        sd = estimate_noise_sd(y)
        if sd > noise_warn:
            out.append(_f("NOISE_LEVEL", "warning", f"{n}: noise sd ~{sd:.4f} exceeds {noise_warn}.", n, sd))
        if y.max() - np.median(y[-10:]) < 0.02:
            out.append(_f("LOW_SIGNAL", "warning", f"{n}: peak-to-baseline difference below 0.02; "
                          "culture too dilute.", n, float(y.max() - np.median(y[-10:]))))
    # replicates
    names = list(S)
    grp = {}
    for n in names:
        g = (groups or {}).get(n) if isinstance(groups, dict) else None
        grp.setdefault(g or group_of(n), []).append(n)
    for g, members in grp.items():
        if len(members) < 2 or not all(np.all(np.isfinite(S[m])) for m in members):
            continue
        Y = np.array([S[m] for m in members])
        level = float(np.mean(np.abs(Y)))
        floor = max(0.01, 0.05 * level)
        if len(members) == 2:
            d = float(np.sqrt(np.mean((Y[0] - Y[1]) ** 2)))
            if d > max(floor, 0.15 * level):
                out.append(_f("REPLICATE_MISMATCH", "warning", f"Replicates of '{g}' differ (RMS {d:.3f}).",
                              None, d))
            continue
        gmed = np.median(Y, axis=0)  # pointwise group median: robust to one outlier when n >= 3
        dist = [float(np.sqrt(np.mean((Y[i] - gmed) ** 2))) for i in range(len(members))]
        med = float(np.median(dist))
        for m, d in zip(members, dist):
            if d > max(outlier_factor * med, floor):
                out.append(_f("OUTLIER_REPLICATE", "warning", f"{m}: deviates from its replicates "
                              f"(RMS {d:.3f} vs median {med:.3f}).", m, d))
    return out


def has_errors(findings) -> bool:
    return any(f["severity"] == "error" for f in findings)
