"""Optional AI-agent layer (Claude tool use). The library itself never needs it.

* TOOLS / dispatch_tool: JSON-schema tool definitions + a dispatcher, usable from any agent framework or MCP server.
* run_agent: a minimal tool-use loop with the Anthropic Python SDK (pip install cyanospectra[agent], ANTHROPIC_API_KEY).
* offline_summary: deterministic text summary, works without any model.
Numbers always come from the library's tools; the model only plans calls and explains results.
"""
from __future__ import annotations
import json
from .benchmark import run_benchmark
from .pipeline import analyze
from .synthetic import generate_spectrum
from ._utils import to_jsonable

DEFAULT_MODEL = "claude-sonnet-5-5"
SYSTEM = ("You are an assistant for analysing in vivo absorption spectra of cyanobacteria with the cyanospectra "
          "library. Always obtain numbers by calling the tools; never invent values. Report QC findings first, "
          "give pigment ratios with their uncertainty, and state that the rule-based interpretation uses "
          "uncalibrated thresholds. Keep answers concise.")

TOOLS = [
    {"name": "analyze_spectra",
     "description": "Analyse spectra pasted from a spreadsheet (first column wavelength in nm, one column per sample). "
                    "Returns QC findings, pigment ratios (with bootstrap uncertainty), fit quality and interpretation.",
     "input_schema": {"type": "object", "properties": {
         "table": {"type": "string", "description": "Pasted table text (tab/;/, delimited, decimal comma or point)."},
         "scattering": {"type": "string", "enum": ["none", "power_law", "offset"], "description": "Preprocessing scattering correction; default none = joint baseline fit."},
         "method": {"type": "string", "enum": ["nnls", "gaussian", "both"]},
         "uncertainty_n": {"type": "integer", "description": "Bootstrap repetitions (0 = off)."}},
         "required": ["table"]}},
    {"name": "generate_synthetic",
     "description": "Generate one synthetic spectrum with known pigment composition (for demos and sanity checks).",
     "input_schema": {"type": "object", "properties": {"noise_sd": {"type": "number"}, "seed": {"type": "integer"}}}},
    {"name": "run_benchmark",
     "description": "Compare Gaussian and NNLS deconvolution against synthetic ground truth (slow-ish, use n_rep<=5).",
     "input_schema": {"type": "object", "properties": {"n_rep": {"type": "integer"}}}},
]


def summarise_result(res: dict) -> dict:
    """Compact, array-free view of an analyze() result for an LLM context."""
    out = {"qc": res["qc"], "default_method": res["default_method"], "samples": {}}
    for n, by in res["deconvolution"].items():
        m = res["default_method"] if res["default_method"] in by else next(iter(by))
        r = by[m]
        unc = (r.get("uncertainty") or {}).get("metrics", {})
        out["samples"][n] = {
            "method": m, "ratios": {k: {"value": v, **({"sd": unc[f"ratio:{k}"]["sd"], "ci95": unc[f"ratio:{k}"]["ci95"]}
                                                       if f"ratio:{k}" in unc else {})} for k, v in r["ratios"].items()},
            "fit": {k: r["fit"][k] for k in ("r2", "rmse")}, "warnings": r["warnings"],
            "other_methods": {k: v for k, v in res["ratios_by_method"][n].items() if k != m},
            "interpretation": res["interpretation"].get(n)}
    return to_jsonable(out)


def dispatch_tool(name: str, args: dict) -> dict:
    if name == "analyze_spectra":
        sc = args.get("scattering", "none")
        payload = {"spectra": args["table"], "preprocessing": {"scattering": None if sc == "none" else sc},
                   "deconvolution": {"method": args.get("method", "both")},
                   "uncertainty": {"method": "bootstrap", "n": int(args.get("uncertainty_n", 30)), "seed": 0}}
        return summarise_result(analyze(payload))
    if name == "generate_synthetic":
        s = generate_spectrum(noise_sd=args.get("noise_sd", 0.002), seed=args.get("seed", 0),
                              centre_jitter=1.0, fwhm_jitter=0.04)
        t = s["truth"]
        tsv = "wavelength\tsynthetic\n" + "\n".join(f"{w:.0f}\t{a:.5f}" for w, a in zip(s["wavelength"], s["absorbance"]))
        return {"table": tsv, "true_ratios": t["ratios"], "true_scatter": t["scatter"]}
    if name == "run_benchmark":
        b = run_benchmark(n_rep=min(int(args.get("n_rep", 3)), 5))
        return to_jsonable({"summary": b["summary"], "best_method": b["best_method"]})
    raise ValueError(f"unknown tool {name}")


def offline_summary(res: dict) -> str:
    """Deterministic plain-text report - no model required."""
    s = summarise_result(res)
    lines = []
    for f in s["qc"]:
        lines.append(f"QC [{f['severity']}] {f['code']}: {f['message']}")
    for n, d in s["samples"].items():
        lines.append(f"\n{n}  ({d['method']}, R2={d['fit']['r2']:.4f})")
        for k, v in d["ratios"].items():
            u = f" \u00b1 {v['sd']:.3f}" if "sd" in v else ""
            lines.append(f"  {k}: {v['value']:.3f}{u}")
        i = d["interpretation"]
        if i:
            lines.append(f"  light regime: {i['light_regime']}; N limitation: {i['nitrogen_limitation']}")
    return "\n".join(lines)


def run_agent(question: str, table_text: str | None = None, client=None, model=DEFAULT_MODEL, max_turns=6) -> str:
    """Let Claude answer a question about spectra, calling the library through tools."""
    if client is None:
        try:
            import anthropic
        except ImportError as e:
            raise ImportError("pip install cyanospectra[agent] and set ANTHROPIC_API_KEY") from e
        client = anthropic.Anthropic()
    content = question + (f"\n\nSpectra (pasted table):\n{table_text}" if table_text else "")
    messages = [{"role": "user", "content": content}]
    for _ in range(max_turns):
        resp = client.messages.create(model=model, max_tokens=2000, system=SYSTEM, tools=TOOLS, messages=messages)
        if resp.stop_reason != "tool_use":
            return "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")
        messages.append({"role": "assistant", "content": resp.content})
        results = []
        for b in resp.content:
            if getattr(b, "type", "") == "tool_use":
                try:
                    r, err = dispatch_tool(b.name, b.input), False
                except Exception as e:
                    r, err = {"error": str(e)}, True
                results.append({"type": "tool_result", "tool_use_id": b.id, "content": json.dumps(r), "is_error": err})
        messages.append({"role": "user", "content": results})
    return "Agent stopped: maximum number of tool-use turns reached."
