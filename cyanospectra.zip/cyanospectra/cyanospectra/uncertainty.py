"""Parameter uncertainty by residual bootstrap or Monte Carlo noise perturbation (seeded)."""
from __future__ import annotations
import numpy as np
from ._utils import estimate_noise_sd
from .derived import flatten_metrics


def estimate_uncertainty(deconvolver, wl, y, result, method="bootstrap", n=50, seed=0, noise_sd=None) -> dict:
    """Refit n perturbed spectra (model structure fixed to the selected one).

    bootstrap:   y* = fitted + residuals resampled with replacement (i.i.d.; understates the error
                 when the residual contains systematic misfit).
    monte_carlo: y* = y + N(0, noise_sd); noise_sd defaults to a robust estimate from the data.
    """
    rng = np.random.default_rng(seed)
    wl, y = np.asarray(wl, float), np.asarray(y, float)
    fitted, res = np.asarray(result["fitted"]), np.asarray(result["residual"])
    sd = noise_sd if noise_sd is not None else estimate_noise_sd(y)
    draws, failed = {}, 0
    for _ in range(int(n)):
        if method == "bootstrap":
            ys = fitted + rng.choice(res, size=res.size, replace=True)
        elif method == "monte_carlo":
            ys = y + rng.normal(0.0, sd, y.size)
        else:
            raise ValueError("method must be 'bootstrap' or 'monte_carlo'")
        try:
            m = flatten_metrics(deconvolver.refit(wl, ys, result))
        except Exception:
            failed += 1
            continue
        for k, v in m.items():
            draws.setdefault(k, []).append(v)
    stats = {}
    for k, v in draws.items():
        a = np.array(v, float)
        a = a[np.isfinite(a)]
        if a.size >= 3:
            stats[k] = {"mean": float(a.mean()), "sd": float(a.std(ddof=1)),
                        "ci95": [float(np.percentile(a, 2.5)), float(np.percentile(a, 97.5))], "n": int(a.size)}
    return {"method": method, "n": int(n), "failed": failed, "seed": seed, "metrics": stats}
