"""Single entry point: analyze(payload: dict) -> dict (JSON-serializable, no file I/O, no global state)."""
from __future__ import annotations
import copy, io, json
import numpy as np
import pandas as pd
from ._utils import as_spectra, to_jsonable
from .classification import interpret_ratios
from .deconvolution import deconvolve
from .parsing import parse_table, parse_metadata
from .preprocessing import preprocess
from .qc import run_qc, has_errors

VERSION = "0.1.0"
# Chosen from the synthetic benchmark (see README): NNLS is most robust across noise, band overlap and
# scattering-correction error; the Gaussian fit gives band centres/widths and is equally good with a joint baseline.
DEFAULT_METHOD = "nnls"
DEFAULT_UNCERTAINTY = {"method": "bootstrap", "n": 30, "seed": 0}
_RESERVED = {"method", "range", "options", "uncertainty", "gaussian", "nnls"}


def _methods(spec):
    if spec in (None, "both"):
        return [DEFAULT_METHOD] + [m for m in ("gaussian", "nnls") if m != DEFAULT_METHOD]
    return [spec] if isinstance(spec, str) else list(spec)


def analyze(payload: dict) -> dict:
    """Run the full chain: parsing -> QC -> preprocessing -> deconvolution -> derived parameters -> interpretation.

    payload keys (all but 'spectra' optional):
      spectra        parsed spectra dict, or pasted text / bytes / path (parsed with parse_table)
      metadata       {sample: {...}} or table; a 'group' field defines replicate groups
      qc             kwargs of run_qc
      preprocessing  {'scattering': 'power_law'|'offset'|None, 'smoothing': 'savgol', 'normalise': ..,
                      'average_replicates': bool, 'drop': [names]}
      deconvolution  {'method': 'nnls'|'gaussian'|'both'|[..], 'range': [lo, hi], 'baseline': ..,
                      'gaussian': {..}, 'nnls': {..}}  (default baseline: joint 'power_law' unless a
                      scattering correction is requested in preprocessing)
      uncertainty    {'method': 'bootstrap'|'monte_carlo', 'n': 30, 'seed': 0}; n=0 disables
      interpret      bool (default True) - rule-based interpretation of the ratios
    """
    p = dict(payload)
    spectra = p["spectra"]
    spectra = as_spectra(spectra if isinstance(spectra, dict) else parse_table(spectra))
    meta = parse_metadata(p["metadata"]) if p.get("metadata") is not None else spectra.get("metadata") or {}
    groups = {n: m.get("group") for n, m in meta.items() if isinstance(m, dict) and m.get("group")}
    qc = run_qc(spectra, groups=groups, **(p.get("qc") or {}))
    pre_cfg = p.get("preprocessing") or {}
    pre, log = preprocess(spectra, pre_cfg, groups)
    dcfg = p.get("deconvolution") or {}
    methods = _methods(dcfg.get("method"))
    shared = {**{k: v for k, v in dcfg.items() if k not in _RESERVED}, **(dcfg.get("options") or {})}
    shared.setdefault("baseline", "none" if pre_cfg.get("scattering") else "power_law")
    unc = p.get("uncertainty", DEFAULT_UNCERTAINTY)
    wl, S = pre["wavelength"], pre["samples"]
    if dcfg.get("range"):
        m = (wl >= dcfg["range"][0]) & (wl <= dcfg["range"][1])
        wl, S = wl[m], {n: y[m] for n, y in S.items()}
    out = {"version": VERSION, "qc": qc, "qc_has_errors": has_errors(qc), "preprocessing_log": log,
           "default_method": methods[0], "methods": methods, "wavelength": wl, "deconvolution": {},
           "ratios": {}, "ratios_by_method": {}, "pigments": {}, "interpretation": {}, "metadata": meta,
           "settings": to_jsonable({k: v for k, v in p.items() if k not in ("spectra", "metadata")})}
    for name, y in S.items():
        out["deconvolution"][name], out["ratios_by_method"][name] = {}, {}
        for m in methods:
            opts = {**shared, **(dcfg.get(m) or {})}
            try:
                res = deconvolve(wl, y, m, uncertainty=unc if unc else None, **opts)
            except Exception as e:  # keep going; report structured failure
                out["qc"].append({"code": "FIT_FAILED", "severity": "error", "sample": name,
                                  "message": f"{m} fit failed: {e}", "value": None})
                continue
            out["deconvolution"][name][m] = res
            out["ratios_by_method"][name][m] = res["ratios"]
        first = next((m for m in methods if m in out["deconvolution"][name]), None)
        if first:
            r = out["deconvolution"][name][first]
            out["ratios"][name] = r["ratios"]
            out["pigments"][name] = r["pigments"]
            if p.get("interpret", True):
                out["interpretation"][name] = interpret_ratios(r["ratios"], p.get("thresholds"))
    return to_jsonable(out)


def to_json(result: dict) -> str:
    """Session file: the full result (incl. settings and preprocessing log) as JSON text."""
    return json.dumps(to_jsonable(result))


def from_json(text: str) -> dict:
    return json.loads(text)


def export_excel(result: dict) -> bytes:
    """Excel workbook as bytes (ratios, pigments, bands, fit quality, QC). Nothing is written to disk."""
    rat, pig, bands, fit = [], [], [], []
    for n, by in result["deconvolution"].items():
        for m, r in by.items():
            unc = (r.get("uncertainty") or {}).get("metrics", {})
            rat.append({"sample": n, "method": m, **{k: v for k, v in r["ratios"].items()},
                        **{f"{k} sd": unc[f"ratio:{k}"]["sd"] for k in r["ratios"] if f"ratio:{k}" in unc}})
            pig.append({"sample": n, "method": m, **{f"{k} area": v["area"] for k, v in r["pigments"].items()},
                        **{f"{k} share": v["share"] for k, v in r["pigments"].items()}})
            bands += [{"sample": n, "method": m, **b} for b in r["bands"]]
            fit.append({"sample": n, "method": m, **r["fit"]})
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as xw:
        for name, rows in (("Ratios", rat), ("Pigments", pig), ("Bands", bands), ("Fit", fit),
                           ("QC", [{k: v for k, v in f.items()} for f in result["qc"]])):
            pd.DataFrame(rows if rows else [{}]).to_excel(xw, sheet_name=name, index=False)
    return buf.getvalue()
