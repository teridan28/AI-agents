"""Optional, fully logged corrections: scattering, smoothing, normalisation, replicate averaging."""
from __future__ import annotations
import numpy as np
from scipy.optimize import curve_fit
from scipy.signal import savgol_filter
from ._utils import as_spectra, group_of, trapz

REF_WL = 500.0  # scattering model: A = a * (lambda / 500 nm)^-b  (a = scattering at 500 nm)


def fit_power_law(wl, y, window=(710.0, None), b_bounds=(0.5, 4.0), fix_b=None):
    """Fit A_scat = a*(lambda/500)^-b in the near-infrared window. Returns (a, b)."""
    wl, y = np.asarray(wl, float), np.asarray(y, float)
    hi = window[1] if window[1] is not None else wl.max()
    m = (wl >= window[0]) & (wl <= hi)
    if m.sum() < 5:
        raise ValueError(f"fewer than 5 points in scattering window {window}; "
                         "use scattering='offset' or fit the baseline jointly (baseline='power_law')")
    x, v = wl[m], y[m]
    if fix_b is not None:
        u = (x / REF_WL) ** (-fix_b)
        return float(max(np.dot(u, v) / np.dot(u, u), 0.0)), float(fix_b)
    b0 = 1.5
    a0 = max(float(np.mean(v)) * (np.mean(x) / REF_WL) ** b0, 1e-6)
    f = lambda xx, a, b: a * (xx / REF_WL) ** (-b)
    try:
        (a, b), _ = curve_fit(f, x, v, p0=[a0, b0], bounds=([0, b_bounds[0]], [np.inf, b_bounds[1]]))
    except Exception:  # fall back to fixed exponent
        return fit_power_law(wl, y, window, b_bounds, fix_b=b0)
    return float(a), float(b)


def power_law(wl, a, b):
    return a * (np.asarray(wl, float) / REF_WL) ** (-b)


def _opt(v):
    if v is None or v is False:
        return None
    if v is True:
        return {}
    if isinstance(v, str):
        return {"method": v}
    return dict(v)


def correct_scattering(sp, method="power_law", window=(710.0, None), b_bounds=(0.5, 4.0), fix_b=None, n_edge=10):
    sp = as_spectra(sp)
    wl = sp["wavelength"]
    out, det = {}, {}
    for n, y in sp["samples"].items():
        if method == "power_law":
            a, b = fit_power_law(wl, y, window, b_bounds, fix_b)
            out[n] = y - power_law(wl, a, b)
            det[n] = {"a500": a, "b": b}
        elif method in ("offset", "offset_750", "offset_800"):
            target = {"offset_750": 750.0, "offset_800": 800.0}.get(method)
            if target is not None:
                k = int(np.argmin(np.abs(wl - target)))
                off = float(np.mean(y[max(0, k - 2): k + 3]))
            else:
                off = float(np.mean(y[-n_edge:]))
            out[n] = y - off
            det[n] = {"offset": off}
        else:
            raise ValueError(f"unknown scattering method '{method}'")
    res = {**sp, "samples": out}
    return res, det


def smooth(sp, window=11, polyorder=3):
    sp = as_spectra(sp)
    window = int(window) | 1
    window = min(window, (sp["wavelength"].size - 1) | 1)
    return {**sp, "samples": {n: savgol_filter(y, window, min(polyorder, window - 1)) for n, y in sp["samples"].items()}}


def normalise(sp, method="chl_peak", wavelength=None, range=(660.0, 700.0)):
    sp = as_spectra(sp)
    wl = sp["wavelength"]
    out = {}
    for n, y in sp["samples"].items():
        if method == "chl_peak":
            m = (wl >= range[0]) & (wl <= range[1])
            s = y[m].max()
        elif method == "max":
            s = y.max()
        elif method == "area":
            s = trapz(y, wl)
        elif method == "wavelength":
            s = float(np.interp(wavelength, wl, y))
        else:
            raise ValueError(f"unknown normalisation '{method}'")
        out[n] = y / s if s else y
    return {**sp, "samples": out}


def average_replicates(sp, groups=None):
    sp = as_spectra(sp)
    g = {}
    for n in sp["samples"]:
        g.setdefault((groups or {}).get(n) or group_of(n), []).append(n)
    mean = {k: np.mean([sp["samples"][m] for m in v], axis=0) for k, v in g.items()}
    sd = {k: (np.std([sp["samples"][m] for m in v], axis=0, ddof=1) if len(v) > 1 else np.zeros_like(sp["wavelength"]))
          for k, v in g.items()}
    return {**sp, "samples": mean, "sd": sd, "metadata": {}}, {k: v for k, v in g.items()}


def preprocess(spectra, config=None, groups=None):
    """Apply steps in fixed order: drop -> average_replicates -> scattering -> smoothing -> normalise.

    Returns (new_spectra, log). Every step is logged with its parameters and fitted details,
    so the same config replays the analysis exactly.
    """
    cfg = config or {}
    sp = as_spectra(spectra)
    log = []
    drop = cfg.get("drop")
    if drop:
        sp = {**sp, "samples": {n: y for n, y in sp["samples"].items() if n not in set(drop)}}
        log.append({"step": "drop", "params": {"samples": list(drop)}})
    o = _opt(cfg.get("average_replicates"))
    if o is not None:
        sp, members = average_replicates(sp, groups)
        log.append({"step": "average_replicates", "params": {}, "details": members})
    o = _opt(cfg.get("scattering"))
    if o is not None:
        method = o.pop("method", "power_law")
        sp, det = correct_scattering(sp, method, **o)
        log.append({"step": "scattering", "params": {"method": method, **o}, "details": det})
    o = _opt(cfg.get("smoothing"))
    if o is not None:
        o.pop("method", None)
        p = {"window": o.get("window", 11), "polyorder": o.get("polyorder", 3)}
        sp = smooth(sp, **p)
        log.append({"step": "smoothing", "params": {"method": "savgol", **p}})
    o = _opt(cfg.get("normalise"))
    if o is not None:
        method = o.pop("method", "chl_peak")
        sp = normalise(sp, method, **o)
        log.append({"step": "normalise", "params": {"method": method, **o}})
    return sp, log
