"""End-to-end demo on synthetic data: python examples/demo.py"""
import cyanospectra as cs
from cyanospectra import viz, agent

data = cs.generate_dataset(n_cultures=1, n_rep=1, seed=1)
spectra = data["spectra"]
result = cs.analyze({
    "spectra": spectra,
    "preprocessing": {"smoothing": "savgol"},
    "deconvolution": {"method": "both"},          # joint power-law baseline by default
    "uncertainty": {"method": "bootstrap", "n": 30, "seed": 0},
})
print(agent.offline_summary(result))               # works without any AI model

name = next(iter(spectra["samples"]))
print("truth:", {k: round(v, 3) for k, v in data["truth"][name]["ratios"].items()})
viz.plot_deconvolution(result["deconvolution"][name]["gaussian"]).savefig("deconvolution.png", dpi=150)
open("result.xlsx", "wb").write(cs.export_excel(result))

# Optional AI agent (needs `pip install cyanospectra[agent]` and ANTHROPIC_API_KEY):
# print(agent.run_agent("Is this culture high-light acclimated?", table_text=pasted_text))
