import json
import numpy as np
import pytest
from matplotlib.figure import Figure
import cyanospectra as cs
from cyanospectra import agent, viz
from cyanospectra.synthetic import generate_spectrum, generate_dataset
from cyanospectra.classification import cnn1d_forward

WL = np.arange(400.0, 751.0)


# ---------------------------------------------------------------- synthetic generator
def test_synthetic_is_seeded_and_truth_consistent():
    a, b = generate_spectrum(seed=5), generate_spectrum(seed=5)
    assert np.array_equal(a["absorbance"], b["absorbance"])
    t = a["truth"]
    assert abs(t["ratios"]["PC/Chl"] - 0.52) < 0.01
    # band areas add up to the pigment amounts
    for p, amt in t["composition"].items():
        assert sum(x["area"] for x in t["bands"] if x["pigment"] == p) == pytest.approx(amt)
    # noise-free spectrum equals clean + scattering
    n = generate_spectrum(noise_sd=0, seed=1)
    assert np.allclose(n["absorbance"], n["truth"]["clean"] + n["truth"]["scattering"])


# ---------------------------------------------------------------- parsing
def _table(sep, dec):
    rows = [["wavelength", "WT_LL_rep1", "WT_LL_rep2"]] + [[str(w), f"{0.5 + w / 5000:.3f}".replace(".", dec),
                                                            f"{0.51 + w / 5000:.3f}".replace(".", dec)] for w in range(400, 421)]
    return "\n".join(sep.join(r) for r in rows)


@pytest.mark.parametrize("sep,dec", [("\t", "."), ("\t", ","), (";", ","), (",", "."), (" ", ".")])
def test_parse_pasted_delimiters_and_decimals(sep, dec):
    sp = cs.parse_pasted(_table(sep, dec))
    assert list(sp["samples"]) == ["WT_LL_rep1", "WT_LL_rep2"]
    assert sp["wavelength"][0] == 400 and sp["wavelength"][-1] == 420
    assert sp["samples"]["WT_LL_rep1"][0] == pytest.approx(0.58, abs=1e-6)


def test_parse_resamples_to_1nm_and_handles_descending_order():
    txt = "wl\tA\n" + "\n".join(f"{w}\t{w / 1000}" for w in range(750, 399, -5))
    sp = cs.parse_pasted(txt)
    assert np.allclose(np.diff(sp["wavelength"]), 1.0)
    assert sp["samples"]["A"][0] == pytest.approx(0.4)


def test_parse_excel_roundtrip(tmp_path):
    import pandas as pd
    p = tmp_path / "x.xlsx"
    pd.DataFrame({"wavelength": WL, "s1": generate_spectrum(seed=1)["absorbance"]}).to_excel(p, index=False)
    assert len(cs.parse_table(p)["wavelength"]) == 351
    assert len(cs.parse_table(p.read_bytes())["wavelength"]) == 351


def test_metadata():
    m = cs.parse_metadata("sample,strain,light\nA_rep1,WT,LL\nB_rep1,MUT,HL")
    assert m["B_rep1"]["light"] == "HL"
    assert cs.metadata_from_names(["WT_LL_rep1"])["WT_LL_rep1"]["light"] == "LL"


# ---------------------------------------------------------------- QC
def test_qc_findings():
    good = generate_spectrum(seed=1)["absorbance"]
    sat = good * 5
    neg = good - 0.3
    sp = {"wavelength": WL, "samples": {"good": good, "sat": sat, "neg": neg}}
    codes = {(f["code"], f["sample"]) for f in cs.run_qc(sp)}
    assert ("SATURATION", "sat") in codes and ("NEGATIVE_VALUES", "neg") in codes
    assert not any(c == "SATURATION" and s == "good" for c, s in codes)


def test_qc_outlier_replicate_and_range():
    base = generate_spectrum(seed=1, noise_sd=0.001)["absorbance"]
    sp = {"wavelength": WL, "samples": {"S_rep1": base, "S_rep2": base + 0.001, "S_rep3": base * 1.6}}
    f = cs.run_qc(sp)
    assert [x["sample"] for x in f if x["code"] == "OUTLIER_REPLICATE"] == ["S_rep3"]
    narrow = {"wavelength": WL[:100], "samples": {"a": base[:100]}}
    assert any(x["code"] == "NARROW_RANGE" and x["severity"] == "error" for x in cs.run_qc(narrow))


# ---------------------------------------------------------------- preprocessing
def test_preprocessing_logged_and_scattering_reduces_baseline():
    s = generate_spectrum(seed=2, noise_sd=0.001)
    sp = {"wavelength": WL, "samples": {"a": s["absorbance"]}}
    out, log = cs.preprocess(sp, {"scattering": "power_law", "smoothing": "savgol", "normalise": "chl_peak"})
    assert [l["step"] for l in log] == ["scattering", "smoothing", "normalise"]
    assert "a500" in log[0]["details"]["a"]
    assert abs(out["samples"]["a"][260:301].max() - 1.0) < 1e-9  # normalised to Qy peak
    out2, _ = cs.preprocess(sp, {"scattering": "power_law"})
    assert abs(out2["samples"]["a"][-10:].mean()) < 0.02


def test_average_replicates():
    s = generate_spectrum(seed=2)["absorbance"]
    sp = {"wavelength": WL, "samples": {"G_rep1": s, "G_rep2": s + 0.02}}
    out, log = cs.preprocess(sp, {"average_replicates": True})
    assert list(out["samples"]) == ["G"] and np.allclose(out["samples"]["G"], s + 0.01)


# ---------------------------------------------------------------- reference library
def test_reference_library_documents_origin_and_unit_area():
    lib = cs.default_library()
    for rec in lib.spectra:
        assert rec["origin"] and rec["method"] and rec["source"]
    S = lib.matrix(WL, ["Chl", "PC"])
    assert S.shape == (351, 2) and (S >= 0).all()
    with pytest.raises(ValueError):
        lib.add({"id": "x", "pigment": "PC", "bands": []})  # undocumented origin


def test_user_can_add_spectrum_without_code_change(tmp_path):
    lib = cs.ReferenceLibrary.load()
    lib.add({"id": "pc_measured", "pigment": "PC", "origin": "in vitro", "solvent": "phosphate buffer",
             "method": "spectrophotometer", "source": "own data", "wavelength": [500, 620, 740], "absorbance": [0, 1, 0]})
    assert lib.render(WL, "PC", "pc_measured").shape == (351,)


# ---------------------------------------------------------------- deconvolution: correctness vs ground truth
def test_recovers_known_ratios_noise_free_no_jitter():
    """Strict check: exact data, oracle scattering -> both methods recover the ratios within 3 %."""
    s = generate_spectrum(noise_sd=0.0, seed=1)
    y = s["absorbance"] - s["truth"]["scattering"]
    for method in ("gaussian", "nnls"):
        r = cs.deconvolve(WL, y, method)
        for k, t in s["truth"]["ratios"].items():
            assert abs(r["ratios"][k] - t) / t < 0.03, (method, k)


@pytest.mark.parametrize("method", ["gaussian", "nnls"])
def test_recovers_known_ratios_realistic_conditions(method):
    """Realistic: noise 0.002, band jitter vs. nominal, scattering fitted jointly.
    Tolerance is statistical (median over 8 spectra) because single ratios such as APC/PC (small band)
    can be off by ~20 % in individual spectra - see README benchmark."""
    c = cs.run_condition(noise_sd=0.002, scatter_mode="joint", n_rep=8, seed=11, methods=(method,))["methods"][method]
    assert c["median_rel_error"] < 0.08, c
    assert c["failure_rate_25pct"] < 0.15, c


def test_gaussian_exact_without_noise_and_centres_within_bound():
    s = generate_spectrum(noise_sd=0.0, seed=1)
    y = s["absorbance"] - s["truth"]["scattering"]
    r = cs.deconvolve(WL, y, "gaussian")
    assert r["fit"]["rmse"] < 1e-5
    for b in r["bands"]:
        assert abs(b["centre"] - next(n for n in cs.get_deconvolver("gaussian").bands if n["name"] == b["name"])["centre"]) <= 5 + 1e-6
    for k, v in s["truth"]["ratios"].items():
        assert r["ratios"][k] == pytest.approx(v, rel=0.02)


def test_pe_strain_is_detected_by_information_criterion():
    s = generate_spectrum({"PE": 8.0}, noise_sd=0.001, seed=4)
    r = cs.deconvolve(WL, s["absorbance"], "gaussian", baseline="power_law")
    assert any(b["pigment"] == "PE" for b in r["bands"])
    assert r["pigments"]["PE"]["area"] == pytest.approx(8.0, rel=0.3)


def test_nnls_weights_nonnegative_and_common_interface():
    s = generate_spectrum(seed=1)
    r = cs.deconvolve(WL, s["absorbance"], "nnls", baseline="power_law")
    assert all(p["area"] >= 0 for p in r["pigments"].values())
    g = cs.deconvolve(WL, s["absorbance"], "gaussian", baseline="power_law")
    assert set(r) >= {"fitted", "residual", "pigments", "ratios", "fit"} and set(g) >= set(r) - {"x"}


def test_uncertainty_is_seeded_and_reasonable():
    s = generate_spectrum(seed=1)
    kw = dict(baseline="power_law", uncertainty={"method": "bootstrap", "n": 15, "seed": 7})
    a = cs.deconvolve(WL, s["absorbance"], "nnls", **kw)["uncertainty"]["metrics"]["ratio:PC/Chl"]
    b = cs.deconvolve(WL, s["absorbance"], "nnls", **kw)["uncertainty"]["metrics"]["ratio:PC/Chl"]
    assert a == b and a["sd"] > 0 and a["ci95"][0] <= a["mean"] <= a["ci95"][1]
    mc = cs.deconvolve(WL, s["absorbance"], "gaussian", baseline="power_law",
                       uncertainty={"method": "monte_carlo", "n": 8})["uncertainty"]
    assert mc["metrics"]["ratio:PC/Chl"]["sd"] >= 0


def test_benchmark_runs_and_documents_failure_modes():
    b = cs.run_benchmark(noise_levels=(0.002,), overlap_scales=(1.0,), scatter_modes=("oracle:0", "oracle:+0.3"), n_rep=3)
    assert b["best_method"] in ("gaussian", "nnls")
    ok = b["sweeps"]["scatter"][0]["methods"]["nnls"]["median_rel_error"]
    bad = b["sweeps"]["scatter"][1]["methods"]["gaussian"]["median_rel_error"]
    assert ok < 0.1 and bad > ok  # scattering error degrades the fit
    assert isinstance(viz.plot_benchmark(b), Figure)


# ---------------------------------------------------------------- pipeline
def test_analyze_end_to_end_json_and_excel():
    d = generate_dataset(n_cultures=1, n_rep=2, seed=1)
    res = cs.analyze({"spectra": d["spectra"], "uncertainty": {"n": 5},
                      "preprocessing": {"smoothing": "savgol"}})
    json.dumps(res)
    assert set(res["ratios"]) == set(d["spectra"]["samples"])
    assert res["preprocessing_log"][0]["step"] == "smoothing"
    assert cs.export_excel(res)[:2] == b"PK"
    assert cs.from_json(cs.to_json(res))["version"] == res["version"]


def test_analyze_accepts_pasted_text_and_replays_identically():
    s = generate_spectrum(seed=1)
    txt = "wavelength\tS1\n" + "\n".join(f"{w:.0f}\t{a:.5f}".replace(".", ",") for w, a in zip(s["wavelength"], s["absorbance"]))
    p = {"spectra": txt, "uncertainty": {"n": 0}, "deconvolution": {"method": "nnls"}}
    r1, r2 = cs.analyze(p), cs.analyze(p)
    assert r1["ratios"] == r2["ratios"] and abs(r1["ratios"]["S1"]["PC/Chl"] - 0.52) < 0.1


def test_analyze_reports_qc_not_prints(capsys):
    s = generate_spectrum(seed=1)["absorbance"] * 6
    r = cs.analyze({"spectra": {"wavelength": WL, "samples": {"x": s}}, "uncertainty": {"n": 0}})
    assert r["qc_has_errors"] and any(f["code"] == "SATURATION" for f in r["qc"])
    assert capsys.readouterr().out == ""


# ---------------------------------------------------------------- visualisation
def test_figures_are_returned_not_shown():
    d = generate_dataset(n_cultures=1, n_rep=1, seed=1)
    sp = d["spectra"]
    r = cs.analyze({"spectra": sp, "uncertainty": {"n": 0}})
    n = list(sp["samples"])[0]
    figs = [viz.plot_spectra(sp), viz.plot_difference(sp, n, list(sp["samples"])[1]),
            viz.plot_derivative(sp, 2), viz.plot_derivative(sp, 4),
            viz.plot_deconvolution(r["deconvolution"][n]["nnls"]), viz.plot_deconvolution(r["deconvolution"][n]["gaussian"]),
            viz.plot_overlay({"a": (WL, WL)})]
    assert all(isinstance(f, Figure) for f in figs)


# ---------------------------------------------------------------- classification
def test_rule_based_interpreter():
    assert cs.interpret_ratios({"PC/Chl": 0.3, "APC/PC": 0.3, "Car/Chl": 0.8, "PBS/Chl": 0.4})["light_regime"] == "HL-like"
    assert cs.interpret_ratios({"PC/Chl": 0.8, "APC/PC": 0.3, "Car/Chl": 0.3, "PBS/Chl": 1.0})["light_regime"] == "LL-like"
    assert cs.interpret_ratios({"PC/Chl": 0.05, "APC/PC": 0.3, "Car/Chl": 0.5, "PBS/Chl": 0.08})["nitrogen_limitation"] == "likely"


def test_classification_strategies_grouped_cv():
    d = generate_dataset(n_cultures=5, n_rep=2, seed=0)
    res = {n: cs.deconvolve(d["spectra"]["wavelength"], y, "nnls", baseline="power_law")
           for n, y in d["spectra"]["samples"].items()}
    out = cs.compare_strategies(d["spectra"], d["labels"], d["groups"], res, n_splits=5)
    assert all(v["grouped"] for v in out.values())
    assert out["features:logreg"]["cv_accuracy_mean"] > 0.8
    assert set(out["features:plsda"]) >= {"cv_accuracy_mean", "train_accuracy_mean", "overfit_gap"}


def test_cnn_numpy_inference_shapes():
    rng = np.random.default_rng(0)
    w = {"conv1_w": rng.normal(size=(8, 1, 9)), "conv1_b": np.zeros(8), "conv2_w": rng.normal(size=(16, 8, 9)),
         "conv2_b": np.zeros(16), "fc_w": rng.normal(size=(3, 16 * 21)), "fc_b": np.zeros(3),
         "x_mean": np.zeros(351), "x_std": np.ones(351), "classes": ["a", "b", "c"]}
    assert cnn1d_forward(w, rng.normal(size=(4, 351))).shape == (4, 3)


# ---------------------------------------------------------------- agent layer
class _Block:
    def __init__(self, **kw): self.__dict__.update(kw)


class _FakeClient:
    """Mimics the Anthropic SDK: first asks for a tool, then answers."""
    def __init__(self, table): self.calls, self.table = 0, table; self.messages = self

    def create(self, **kw):
        self.calls += 1
        if self.calls == 1:
            return _Block(stop_reason="tool_use", content=[_Block(type="tool_use", id="t1", name="analyze_spectra",
                                                                  input={"table": self.table, "uncertainty_n": 0})])
        tr = kw["messages"][-1]["content"][0]
        assert tr["type"] == "tool_result" and not tr["is_error"] and "PC/Chl" in tr["content"]
        return _Block(stop_reason="end_turn", content=[_Block(type="text", text="done")])


def test_agent_tool_loop_with_fake_client():
    t = agent.dispatch_tool("generate_synthetic", {"seed": 1})
    assert agent.run_agent("analyse", client=_FakeClient(t["table"])) == "done"
    assert all({"name", "description", "input_schema"} <= set(x) for x in agent.TOOLS)
